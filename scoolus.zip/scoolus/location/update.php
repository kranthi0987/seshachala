<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
	$stopcountstore;
	$busid = $_GET["busid"];
	$long =  $_GET["long"];
	$lat  =  $_GET["lat"];
	$acc  =  $_GET["acc"];
	$id= 13;
	$nextlong1;	
	$nextlat1;	
	$nextlong2;	
	$nextlat2;	
	//echo $long . $lat;
	$query="INSERT INTO `trck`(`long`, `lat`, `acc`) VALUES ('$long','$lat','$acc')";
		
	$result = mysql_query( $query , $my_connection) or die(mysql_error());
	
	$url = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=".$lat."+".$long."&destinations=".formallactivestops($my_connection,$id)."&mode=travelMode&language=fr-FR&key=AIzaSyAvK5TmfFTA9cmljPD6lbw1W7YqiaAwfSo";
	$stopcountstore = formallactivestopsarray($my_connection,$id);
	$result_string = file_get_contents($url);
	//echo $result_string;
	$result = json_decode($result_string, true);
	$foricount =0;
	for($i; $i<count($result['rows'][0]['elements']);$i++){
		$time = $result['rows'][0]['elements'][$i]['duration']['value'];
		if($time<450)		
		//if($acc<200)
		{
			$temp = explode(",",$stopcountstore); 
			echo  $stop = $temp[$foricount];
			sendmessage($my_connection,$busid ,$stop);
			
		}
		$foricount++;
		
		
	}
	for($i; $i<count($result['rows'][0]['elements']);$i++){
		$dist= $result['rows'][0]['elements'][$i]['distance']['value'];
		if($dist<200){
			if($acc<100){
			sendreached($my_connection,$i);
			}
			else{
				
			}
		}
		
	}
	$stopcountstore ="";
			
	function formallactivestops($my_connection,$id){
		$query="SELECT * FROM `dailytrips` WHERE `bus_id` = $id and `active` ='yes'";
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		$returnstring ="";
		while($row = mysql_fetch_array($result)) {
			$stopcountstore .= $row['stopnumber'].",";
			$returnstring .= $row['lat']. "+" .$row['long']."|";
		}
		$stopcountstore  = rtrim($stopcountstore , ",");
		//echo "stops ry: ".$stopcountstore;
		$returnstring = rtrim($returnstring , "|");
		return $returnstring;
		
	}	
	function formallactivestopsarray($my_connection,$id){
		$query="SELECT * FROM `dailytrips` WHERE `bus_id` = $id and `active` ='yes'";
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		$returnstring ="";
		while($row = mysql_fetch_array($result)) {
			$stopcountstore .= $row['stopnumber'].",";
			
		}
		$stopcountstore  = rtrim($stopcountstore , ",");
		
		return $stopcountstore;
		
	}	
	
	function sendmessage($my_connection,$busid, $stopid){
		//echo $stopid;
		//echo $query="UPDATE `dailytrips` SET `messagesent`='yes' WHERE `active`='yes' AND `bus_id` = $busid AND `stop_id` = $stopid";
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		

                //sedning mil
                $from = "webmaster@scoolus.com"; // sender
    $subject = "us reched: ";
    $message = "distance to next stop: ";
    // message lines should not exceed 70 characters (PHP rule), so wrap it
    $message = wordwrap($message, 70);
    // send mail
    mail("yyeshwanth4@gmail.com",$subject,$message,"From: $from\n");


	}	
	function sendreached($my_connection,$id){
		
	}
?>