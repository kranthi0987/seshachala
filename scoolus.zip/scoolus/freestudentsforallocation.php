<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
		
		$query ="SELECT * FROM `Student` WHERE `bus_id` ='0'";
		$out ="";
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		while($row = mysql_fetch_array($result)) {
			$out .=  $row['id']."///".$row['firstname']."///". $row['rollnumber'] ."///". $row['class'] .",,,";	
		}
		$out = rtrim($out,",,,");
		echo $out;
?>
