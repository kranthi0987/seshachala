<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Student Manager</title>
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<link rel="stylesheet" href="css/bootstrap.css"/>
<link rel="stylesheet" href="css/bootstrapValidator.min.css"/>
<link rel="stylesheet" href="css/jquery.dataTables.css"/>

<link rel="stylesheet" href="css/main.css">
<style>
  #sortable { list-style-type: none; margin: 8; padding: 0; }
  #sortable li { margin: 0 5px 5px 5px; padding: 5px; font-size: 1.2em; height: 1.5em; }
  html>body #sortable li { height: 1.5em; line-height: 1.2em; }
  .ui-state-highlight { height: 1.5em; line-height: 1.2em; }
  </style>
  
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.dataTables.js"></script>
<script type="text/javascript">
      $(document).ready(function(){
			var running = false;
			$("#createstudent").click(function(event){
			
			event.preventDefault();
			
			if(!running){
				running = true;
				
				var num = $("#rollnum").val();
				var classs = $("#classs").val();
				var first = $("#first").val();
				var last = $("#last").val();
				var gaurdian = $("#gaurdian").val();
				var phone = $("#phone").val();
				
				var datastring = num + ",,," + classs + ",,," + first + ",,," + last + ",,," + gaurdian + ",,," + phone;
				if(datastring.indexOf(",,,,,,")> -1){
					alert("Fill All Fields");
					running = false;
					return;
				}
				else{
					
				}
				console.log(datastring);
				var url2 = "http://seshachalavanadarshani.com/scoolus/createstudent.php?data="+ datastring;
				/// call your function here
				$.ajax({url:url2,success:function(result){
					alert("Created");
					$("#rollnum").val("");
					$("#classs").val("");
					$("#first").val("");
					$("#last").val("");
					$("#gaurdian").val("");
					$("#phone").val("");
					
					running = false;
				}});
			}			
			
			});
			
			
			// prepare allocate bus tab on click
			$("#allocatetab").one("click",function(){
				
				// load students

				var url2 ="http://seshachalavanadarshani.com/scoolus/freestudentsforallocation.php";
				
				/// call your function here
				$.ajax({url:url2,success:function(result){
					//alert(result);
					var id ="";
					var list = result.split(",,,");	 
					for(var i = 0 ; i< list.length; i++){
						var list2 = list[i].split("///");	 
							//alert("<option id='"+ list2[0]+"'>"+list2[1]+"</option>" );
							$( "<li class='list-group-item'><div style='float:left; width: 80%'  bid='"+ list2[0]+"' class='landmark '>"+list2[1]+" | Roll: "+list2[2]+" |class: "+list2[3]+"</div><span style='' class='glyphicon glyphicon-share-alt  addtobus'></span></li>" ).appendTo( "#nonenrolled ul" );	
							//alert(list2.length);
					}
					
							
				}});	
				
				
				
				 url2 ="http://seshachalavanadarshani.com/scoolus/busnames.php";
				
				/// call your function here
				$.ajax({url:url2,success:function(result){
					//alert(result);
					var id ="";
					var list = result.split(",,,");	 
					for(var i = 0 ; i< list.length; i++){
						var list2 = list[i].split("///");	 
							//alert("<option id='"+ list2[0]+"'>"+list2[1]+"</option>" );
							$( "<option id='"+ list2[0]+"'>"+list2[1]+"</option>" ).appendTo( "#buslist" );	
							if( i == 0){
								id = list2[0];
							}
							
					}
					var sid =1;
					var stops;
					if(list.length >0){
						var url3 = "http://seshachalavanadarshani.com/scoolus/stopnames.php?bus="+id;
						$.ajax({url:url3,success:function(result){
							 stops = result.split(",,,");
							
							for( var i =0; i< stops.length; i++){
								if(stops[i] !=""){
									var more = stops[i].split("///");
									$( "<option id='sortlisthold' dbid='"+more[3]+"' long='"+more[2]+"' lat='"+more[1]+"' stop='"+more[0]+"'  class='' >"+more[0]+"</option>" ).appendTo( "#stoplist" );	
									if( i == 0){
										sid = more[3];
									}
								}
							}
							
							if(stops.length >0){
								var url3 = "http://seshachalavanadarshani.com/scoolus/getstudentsinstop.php?bid="+id+"&sid="+sid;
								$.ajax({url:url3,success:function(result){
									var std2 = result.split(",,,,,");
									
									for( var i =0; i< std2.length; i++){
										if(std2[i] !=""){
											var more = std2[i].split(",,,");
											$( "<li class='list-group-item' bid='"+more[0]+"' new='yes'>"+more[1]+"</li>").appendTo("#addedlist ul");
										}
									}
								}});
							}
						}});
					}
					
					
					
							
				}});	
				
				$("#loading1").hide();
				$("#allocatehold").show();				
				
			});
			
			
			// on stop changed
			
			$("#stoplist").on('change',function(){
				
				$("#addedlist ul").html("");
				var url3 = "http://seshachalavanadarshani.com/scoolus/getstudentsinstop.php?bid="+$("#buslist").children(":selected").attr("id")+"&sid="+$("#stoplist").children(":selected").attr("dbid");
				console.log(url3);
				$.ajax({url:url3,success:function(result){
					var std2 = result.split(",,,,,");
					
					for( var i =0; i< std2.length; i++){
						if(std2[i] !=""){
							var more = std2[i].split(",,,");
							$( "<li class='list-group-item' bid='"+more[0]+"' new='yes'>"+more[1]+"</li>").appendTo("#addedlist ul");
						}
					}
				}});	
			});
			
			// on bus selected change update stops
			$('#buslist').on('change', function() {
			  //alert( $(this).children(":selected").attr("id") ); // or $(this).val()
				$("#stoplist").html("");
				$("#addedlist ul").html("");
				
				id = $(this).children(":selected").attr("id");
					
				var url3 = "http://seshachalavanadarshani.com/scoolus/stopnames.php?bus="+$(this).children(":selected").attr("id");
					$.ajax({url:url3,success:function(result){
						var stops = result.split(",,,");
						
						for( var i =0; i< stops.length; i++){
							if(stops[i] !=""){
								var more = stops[i].split("///");
								$( "<option id='sortlisthold' dbid='"+more[3]+"' long='"+more[2]+"' lat='"+more[1]+"' stop='"+more[0]+"'  class='' >"+more[0]+"</option>" ).appendTo( "#stoplist" );	
								if( i == 0){
									sid = more[3];
								}
							}
						}
						
						
						if(stops.length >0){
							var url3 = "http://seshachalavanadarshani.com/scoolus/getstudentsinstop.php?bid="+id+"&sid="+sid;
							$.ajax({url:url3,success:function(result){
								var std2 = result.split(",,,,,");
								
								for( var i =0; i< std2.length; i++){
									if(std2[i] !=""){
										var more = std2[i].split(",,,");
										$( "<li class='list-group-item' bid='"+more[0]+"' new='yes'>"+more[1]+"</li>").appendTo("#addedlist ul");
									}
								}
							}});
						}
					}});
	
				
				
			});
			
			
			$('#nonenrolled ul').on('click', 'li .addtobus', function(){
				var  bid = $(this).prev().attr("bid");
				var val = $(this).prev().html();
				$("<li class='list-group-item' bid='"+bid+"' new='yes'>"+val+"</li>").appendTo("#addedlist ul");
				$(this).remove();
			});
			
			
			$("#updatestop").click(function(){
				var xxx = $('<div>' + $("#addedlist .list-group").html() + '</div>');
				//alert(xxx);
				 var id = $("#buslist").children(":selected").attr("id")
				 var sid = $("#stoplist").children(":selected").attr("dbid")
				 var up = "busid="+id+"&sid="+sid +"&data=";		
				for(var i =0; i< xxx.find(".list-group-item").length; i++){
						var j = i+1;
						//alert(xxx.find(".input-group:nth-child("+j+")").html());
						var bid = xxx.find(".list-group-item:nth-child("+j+")").attr("bid");
						up += bid+ ",,,";
						//xxx.find(".input-group:not(.done:first)").addClass("done");
				}
				up = up.slice(0,-3)
				//alert(up);
				console.log(up);
					
				var url3 = "http://seshachalavanadarshani.com/scoolus/updatestudentstop.php?"+up;
				$.ajax({url:url3,success:function(result){
					alert("updated");
				}});
				
				
			});
			
			
			// #### Dis allocate tab click events ####
			$("#disallocatetab").one("click", function(){
				$( "#alltable" ).load( "allstudents.php", function(){
					$('#alltable').dataTable();
				});
			});
			
			
			$("#alltable").on("click",".disalocatestudent",function(event){
				event.preventDefault();
				
				var url3 = "http://seshachalavanadarshani.com/scoolus/dissallocatestudent.php?id="+$(this).attr("id");
				console.log(url3);
				$.ajax({url:url3,success:function(result){
					$(this).hide();
				},error:function(){
				
					console.log("error");
				}});	
				
				//var txt = $('<tr>'+ $(this).closest("tr").html() +'</tr>');
				//alert(txt);
				//txt.find(".busrelated:nth-child(1)").html("0");
				//txt.find(".busrelated:nth-child(2)").html("0");
				//$(this).closest("tr").html(txt);
				//$(this).siblings().html("0");
				//var ele = $(this).closest("tr");
				//$(ele .busrelated).html("0");
			});
		
		});
	  	
	  
    </script>
</head>

<body>
	<div id="wrapper">
        <div id="menu">
            <span class="logocontaner">
				<img src="img/logo.png" />
			</span>
            <ul id="links">
            	<a href="index.php">Track Bus</a>
                <a href="home.php">Bus Manager</a>
            	<a class="active" href="studentmanager.php">Student Manager</a>
            	<a href ="messagemanager.php" >Message Manager</a>
            </ul>
        </div>
        <div id="content" class="">
            <div class="col-sm-3" style="padding-right: 0px;">
                <div class="sidebar-nav">
                    <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
                        <li class="active"><a id="cretust" href="#buscreate" data-toggle="tab">Register Student</a></li>
                        <li id="crtstop"><a id="allocatetab" href="#allocate" data-toggle="tab">Allocate Bus</a></li>
                        <li id="crtstop"><a id="disallocatetab" href="#disallocate" data-toggle="tab">Dis-Allocate Bus</a></li>
                        
                    </ul>
                </div>
            </div>
           
            
            <div class="col-sm-9 maincontent" style="min-height:100px;">
                <div class="sidebar-nav">
             		<!-------->
                    <div id="tabcontent">
                        
                        <div id="my-tab-content" class="tab-content">
                            <div class="tab-pane active" id="buscreate">
                                <div class="page-header">
								<h1><small>Create Student</small></h1>
							</div>
								<form class="form-horizontal col-sm-offset-2 col-sm-8"  role="form" style="border: 1px solid #DDD; border-radius: 5px; padding:15px; margin-bottom:15px;">
                                    <div class="form-group">
                                      <label for="studentnumber" class="col-sm-4  control-label">Student Number</label>
                                      <div class="col-sm-8">
                                         <input type="text" class="form-control" id="rollnum" 
                                            placeholder="Enter Roll Number">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label for="class" class="col-sm-4  control-label">Class</label>
                                      <div class="col-sm-8">
                                         <input type="text" class="form-control" id="classs" 
                                            placeholder="Enter Class">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label for="first" class="col-sm-4  control-label">Firstname</label>
                                      <div class="col-sm-8">
                                         <input type="text" class="form-control" id="first" 
                                            placeholder="Enter Fisrt Name">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label for="last" class="col-sm-4  control-label">Last Name</label>
                                      <div class="col-sm-8">
                                         <input type="text" class="form-control" id="last" 
                                            placeholder="Enter Last Name">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label for="gaurdian" class="col-sm-4  control-label">Gaurdian</label>
                                      <div class="col-sm-8">
                                         <input type="text" class="form-control" id="gaurdian" 
                                            placeholder="Enter Gaurdian Name">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label for="phonenumber" class="col-sm-4  control-label">Phone</label>
                                      <div class="col-sm-8">
                                         <input type="text" class="form-control" id="phone" 
                                            placeholder="Enter Phone Number">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <div class="col-sm-offset-10 col-sm-2">
                                         <button id="createstudent" type="submit" class="btn btn-default col-sm-12">Create</button>
                                      </div>
                                   </div>
								</form>
                                
                                    
                                                                  
                            </div>
                            <div class="tab-pane" id="allocate">
                                <div id="loading1"  style="padding:55px;">
									<center><img width="30" src="img/ajax-loader.gif" /></center>
                                </div>
                                <div id="allocatehold" class="row fade in">
                                    <div class="col-sm-6">
										<div class="page-header">
										<h3>Non Enrolled Students</h3>
										</div>
                                    	<div id="nonenrolled">
											<ul class="list-group">
											  
											</ul>

										
										</div>
										
                                    </div>
                                    <div class="col-sm-6">
										<div class="page-header">
										<h3>Enroll Students</h3>
										</div>
										
                                        <div class="form-group row">
                                            <label for="busnum" class="col-sm-5 control-label">select bus</label>
                                              <div class="col-sm-7">
                                                <select id="buslist" class="form-control" >
                                                	
                                                </select>
                                              </div>
                                            	
                                        </div>
										
                                        <div class="form-group row">
                                            <label for="busnum" class="col-sm-5 control-label">select stop</label>
                                              <div class="col-sm-7">
                                                <select id="stoplist" class="form-control" >
                                                	
                                                </select>
                                              </div>
                                            	
                                        </div>
										
					<div id="addedlist" class="">
						<ul class="list-group">
						  
						</ul>

						<div class="form-group">
                          <div class=" col-sm-12">
                             <button id="updatestop" type="submit" class="btn btn-default col-sm-12">Add Students</button>
                          </div>
                       </div>
					</div>	
                                    </div>
                                   
									
                                </div>    
                            </div>
                            <div class="tab-pane" id="disallocate">
                                <div id="diallocatehold" class="fade in">
                                    <div class="page-header">
									  <h1>Dis-Allocate Students</h1>
									</div>
                                    <div class="">
										<table id="alltable" class="table table-striped table-bordered table-condensed">
										
										</table>
                                    </div>
                                    
                                </div>    
                            </div>
                            
                        </div>
                    </div>
             	</div>
            </div>    
            <div style="clear: both;"></div>
        </div>
		<div class="footer">
	<div class="inner2">
	 
	</div>
</div>	

	</div>
</body>
</html>