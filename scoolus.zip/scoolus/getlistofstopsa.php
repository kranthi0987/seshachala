<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
		$id =  $_GET["id"];
	
		$query ="SELECT * FROM `bus_stops` WHERE `bus_id` = '$id' ORDER BY `bus_stops`.`stop_number` ASC";
		$out ="";
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		while($row = mysql_fetch_array($result)) {
			$out .=  $row['id']. "///".$row['lat'] . "///".$row['long'] . "///".$row['name'] .",,,";	
		}
		$out = rtrim($out,",,,");
		echo $out;
?>
