<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
	$bid=  $_GET["bid"];
	$sid  =  $_GET["sid"];
	$out = "";
	//echo $long . $lat;
	$query="SELECT * FROM `Student` WHERE `bus_id` = '$bid' AND `busstop_id` ='$sid'";
		
	$result = mysql_query( $query , $my_connection) or die(mysql_error());
	while($row = mysql_fetch_array($result)) {
		  
		$out .= $row['id'] .",,," .$row['firstname']."| Roll: ".$row['rollnumber']." |class: ".$row['class'].",,,,,";	
	}
	$out = rtrim($out,",,,");
	echo $out;
		
?>