<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
	//echo $data =  $_GET["data"];
	
	$splitted = explode(",,,",$data);
	
	$query = "INSERT INTO `Student`(`rollnumber`, `class`, `firstname`, `lastname`, `gaurdian`, `phone`) VALUES ('$splitted[0]', '$splitted[1]', '$splitted[2]', '$splitted[3]', '$splitted[4]', '$splitted[5]')";
	echo $query;		
	$result = mysql_query( $query , $my_connection) or die(mysql_error());
		
?>