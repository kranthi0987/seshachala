<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bus Manager</title>
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<link rel="stylesheet" href="css/bootstrap.css"/>
<link rel="stylesheet" href="css/bootstrapValidator.min.css"/>

<link rel="stylesheet" href="css/main.css">
<style>
  #sortable { list-style-type: none; margin: 8; padding: 0; }
  #sortable li { margin: 0 5px 5px 5px; padding: 5px; font-size: 1.2em; height: 1.5em; }
  html>body #sortable li { height: 1.5em; line-height: 1.2em; }
  .ui-state-highlight { height: 1.5em; line-height: 1.2em; }
  </style>
  
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript">
      $(document).ready(function){
			
			
		
		});
	  	
	  
    </script>
</head>

<body>
	<div id="wrapper">
        <div id="menu">
            <ul id="links">
            	<li class="active">Bus Manager</li>
            	<li>Student Manager</li>
            	<li>Message Manager</li>
            </ul>
        </div>
        <div id="content" class="row">
            <div class="col-sm-3" style="padding-right: 0px;">
                <div class="sidebar-nav">
                    <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
                        <li class="active"><a id="cretust" href="#buscreate" data-toggle="tab">Register Student</a></li>
                        <li id="crtstop"><a href="#allocate" data-toggle="tab">Allocate Bus</a></li>
                        <li id="crtstop"><a href="#disallocate" data-toggle="tab">Dis-Allocate Bus</a></li>
                        
                    </ul>
                </div>
            </div>
           
            
            <div class="col-sm-9 maincontent" style="min-height:100px;">
                <div class="sidebar-nav">
             		<!-------->
                    <div id="tabcontent">
                        
                        <div id="my-tab-content" class="tab-content">
                            <div class="tab-pane active" id="buscreate">
                                <div class="page-header">
								<h1><small>Create Student</small></h1>
							</div>
								<form class="form-horizontal" role="form">
                                    <div class="form-group">
                                      <label for="busnum" class="col-sm-2 control-label">Bus Number</label>
                                      <div class="col-sm-10">
                                         <input type="text" class="form-control" id="busnum" 
                                            placeholder="Enter Bus Number">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <div class="col-sm-offset-10 col-sm-2">
                                         <button id="ctretus" type="submit" class="btn btn-default col-sm-12">Create</button>
                                      </div>
                                   </div>
								</form>
                                
                                    
                                                                  
                            </div>
                            <div class="tab-pane" id="allocate">
                                <div id="loading1"  style="padding:55px;">
									<center><img width="30" src="img/ajax-loader.gif" /></center>
                                </div>
                                <div id="allocatehold" class="fade in">
                                    <div class="page-header">
									  <h1>Allocate Students</h1>
									</div>
                                    <div class="row">
    
                                    </div>
                                    
                                </div>    
                            </div>
                            <div class="tab-pane" id="disallocate">
                                <div id="loading2" style="padding:55px;">
									<center><img width="30" src="img/ajax-loader.gif" /></center>
                                </div>
                                <div id="diallocatehold" class="fade in">
                                    <div class="page-header">
									  <h1>Dis-Allocate Students</h1>
									</div>
                                    <div class="row">
    
                                    </div>
                                    
                                </div>    
                            </div>
                            
                        </div>
                    </div>
             	</div>
            </div>    
            
        </div>
	</div>
</body>
</html>