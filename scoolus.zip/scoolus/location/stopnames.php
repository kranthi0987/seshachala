<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
		
		$bus = $_GET["bus"];
		//echo $bus;
		$query ="SELECT * FROM `bus_stops` WHERE `bus_id` =$bus  ORDER BY stop_number";
		$out ="";
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		while($row = mysql_fetch_array($result)) {
			$out .=  $row['name']."///".$row['lat']."///". $row['long'] ."///". $row['id'] .",,,";	
		}
		$out = rtrim($out,",,,");
		echo $out;
?>
