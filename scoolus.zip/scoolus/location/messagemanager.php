<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<title>Student Manager</title>
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<link rel="stylesheet" href="css/bootstrap.css"/>
<link rel="stylesheet" href="css/bootstrapValidator.min.css"/>
<link rel="stylesheet" href="css/jquery.dataTables.css"/>

<link rel="stylesheet" href="css/main.css">
<style>
  #sortable { list-style-type: none; margin: 8; padding: 0; }
  #sortable li { margin: 0 5px 5px 5px; padding: 5px; font-size: 1.2em; height: 1.5em; }
  html>body #sortable li { height: 1.5em; line-height: 1.2em; }
  .ui-state-highlight { height: 1.5em; line-height: 1.2em; }
  </style>
  
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script src="js/bootstrap.min.js"></script>

</head>
<script >
$(document).ready(function(e) {
    
	
	$('.btn-toggle').click(function() {
		$(this).find('.btn').toggleClass('active');  
		
		if ($(this).find('.btn-primary').size()>0) {
			$(this).find('.btn').toggleClass('btn-primary');
		}
		if ($(this).find('.btn-danger').size()>0) {
			$(this).find('.btn').toggleClass('btn-danger');
		}
		if ($(this).find('.btn-success').size()>0) {
			$(this).find('.btn').toggleClass('btn-success');
		}
		if ($(this).find('.btn-info').size()>0) {
			$(this).find('.btn').toggleClass('btn-info');
		}
		
		$(this).find('.btn').toggleClass('btn-default');
		   
	});
	
	$('form').submit(function(){
		alert($(this["options"]).val());
		return false;
	});
});
</script>
<body>
<div id="wrapper">
        <div id="menu">
            <ul id="links">
            <li class=""><a href="index.php">Track Bus</a></li>
            	<li><a href="home.php">Bus Manager</a></li>
            	<li class=""><a href="studentmanager.php">Student Manager</a></li>
            	<li class="active"><a href ="messagemanager.php" >Message Manager</a></li>
            </ul>
        </div>
        <div id="content" class="">
<div class="container"></div><div class="container">
  <h2>Configure Message Delivery</h2>
  <!-- form radio buttons example -->
  <br />
  <h4>Morning bus start message</h4>
  <form class="form">
  <div class="btn-group btn-toggle" data-toggle="buttons">
    <label class="btn btn-primary active">
      <input type="radio" name="options" value="option1"> On
    </label>
    <label class="btn btn-default">
      <input type="radio" name="options" value="option2" checked=""> Off
    </label>
  </div>
  
  </form>  

  <h4>Morning bus near by alert</h4>
  <form class="form">
  <div class="btn-group btn-toggle" data-toggle="buttons">
    <label class="btn btn-primary active">
      <input type="radio" name="options" value="option1"> On
    </label>
    <label class="btn btn-default">
      <input type="radio" name="options" value="option2" checked=""> Off
    </label>
  </div>
  
  </form>  
  
  <h4>Evening bus start alert</h4>
  <form class="form">
  <div class="btn-group btn-toggle" data-toggle="buttons">
    <label class="btn btn-primary active">
      <input type="radio" name="options" value="option1"> On
    </label>
    <label class="btn btn-default">
      <input type="radio" name="options" value="option2" checked=""> Off
    </label>
  </div>
  
  </form>  
  <h4>Evening bus near by alert</h4>
  <form class="form">
  <div class="btn-group btn-toggle" data-toggle="buttons">
    <label class="btn btn-primary active">
      <input type="radio" name="options" value="option1"> On
    </label>
    <label class="btn btn-default">
      <input type="radio" name="options" value="option2" checked=""> Off
    </label>

  </div>
</form>  

</div>
  </div>
  </div>
</body>
</html>
