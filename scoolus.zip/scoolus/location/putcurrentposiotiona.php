<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
	$long =  $_GET["long"];
	$lat  =  $_GET["lat"];
	$id   =  $_GET["id"];
	//echo $long . $lat;
		$query="INSERT INTO `position`(`bus_id`, `lat`, `long`) VALUES ('$id','$lat','$long')"; 
			
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		
?>