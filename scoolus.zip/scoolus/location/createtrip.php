<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
	//$id =  $_GET["id"];
	$id = 13;
	//$stops[];
	setstopsinactive($id,$my_connection );
	setlistofstops($id,$my_connection );
	
	// insert new records 
	function setlistofstops($id, $my_connection ){
			
		$query="SELECT * FROM `bus_stops` WHERE `bus_id` = $id ORDER BY `stop_number` ASC";
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		$stopcount = 1;
		while($row = mysql_fetch_array($result)) {
			//echo $row['name'] ."---";
			$longx = $row['long'];
			$latx= $row['lat'];
			$stop_numberx= $row['stop_number'];
			//$query="INSERT INTO `dailytrips` ( `stopnumber`) VALUES ()";	
			
			$query="INSERT INTO `dailytrips`( `bus_id`,`stop_id`, `long`, `lat`, `stopnumber`) VALUES ($id,$stopcount,$longx ,$latx,$stop_numberx)";	
			$result2 = mysql_query( $query , $my_connection) or die(mysql_error());
		   	$stopcount++;
		}
	}
	
	// set any active route related to this bus	
	function setstopsinactive($id, $my_connection ){
			
		$query="UPDATE `dailytrips` SET `active`='no' WHERE `bus_id` ='$id'";	
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		
	}
?>