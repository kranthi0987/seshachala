package com.example.location;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import android.R.string;
import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.StrictMode;
import android.util.Log;
import android.widget.Toast;

public class MyService extends Service {
	
    
	public MyService() {
	}

	@Override
	public IBinder onBind(Intent intent) {
		// TODO: Return the communication channel to the service.
		throw new UnsupportedOperationException("Not yet implemented");
	}
	
	
	@Override
    public void onCreate() {
        Toast.makeText(this, "The new Service was Created", Toast.LENGTH_LONG).show();
       
    }
	public Handler mHandler = new Handler();
    public int count = 0;
    @Override
    public void onStart(Intent intent, int startId) {
    	// For time consuming an long tasks you can launch a new thread here...
        Toast.makeText(this, " Service Started", Toast.LENGTH_LONG).show();
        
        new Thread(new Runnable() {
            @Override
            public void run() {
                // TODO Auto-generated method stub
                while (true) {
                    try {
                        Thread.sleep(10000);
                        mHandler.post(new Runnable() {

                            @Override
                            public void run() {
                                // TODO Auto-generated method stub
                                // Write your code here to update the UI.
                            	count++;
                            	String xxx = " counter = " + count;
                            	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                        	    StrictMode.setThreadPolicy(policy);

                        		// Creating HTTP client
                        		HttpClient httpClient = new DefaultHttpClient();
                        		// Creating HTTP Post
                        		HttpPost httpPost = new HttpPost(
                        				"http://www.seshachalavanadarshani.com/scoolus/hit.php?data="+count);

                        		

                        		// Making HTTP Request
                        		try {
                        			HttpResponse response = httpClient.execute(httpPost);

                        			// writing response to log
                        			Log.d("Http Response:", response.toString());
                        		} catch (ClientProtocolException e) {
                        			// writing exception to log
                        			e.printStackTrace();
                        		} catch (IOException e) {
                        			// writing exception to log
                        			e.printStackTrace();

                        		}
                            	 
                            }
                        });
                    } catch (Exception e) {
                        // TODO: handle exception
                    }
                }
            }
        }).start();
   
    }
 
    @Override
    public void onDestroy() {
        Toast.makeText(this, "Service Destroyed", Toast.LENGTH_LONG).show();
        
    }
}
