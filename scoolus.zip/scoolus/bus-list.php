<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
		
		$query ="SELECT bus.id, bus.number, COUNT( bus_stops.bus_id ) AS stops
FROM  `bus` 
LEFT JOIN  `bus_stops` ON bus_stops.bus_id = bus.id
GROUP BY bus_stops.bus_id,bus.id";
		$out ="";
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		while($row = mysql_fetch_array($result)) {
			$out .=  $row['id']. "///".$row['number'] . "///".$row['stops'] .",,,";	
		}
		$out = rtrim($out,",,,");
		echo $out;
?>
