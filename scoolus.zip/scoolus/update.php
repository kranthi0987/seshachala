<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
	$stopcountstore;
	$busid = $_GET["busid"];
	$long =  $_GET["long"];
	$lat  =  $_GET["lat"];
	$acc  =  $_GET["acc"];
	$id= 2;
	$busid = $id;
	$sleepcounter =  checktime($my_connection, $busid);
	if($sleepcounter !=0){
		if($sleepcounter >2){
			return;
		}
	}
	$nextlong1;	
	$nextlat1;	
	$nextlong2;	
	$nextlat2;	
	//echo $long . $lat;
	$query="INSERT INTO `trck`(`long`, `lat`, `acc`) VALUES ('$long','$lat','$acc')";
		
	$result = mysql_query( $query , $my_connection) or die(mysql_error());
	
	$url = "https://maps.googleapis.com/maps/api/distancematrix/json?origins=".$lat."+".$long."&destinations=".formallactivestops($my_connection,$id)."&mode=travelMode&language=fr-FR&key=AIzaSyAvK5TmfFTA9cmljPD6lbw1W7YqiaAwfSo";
	$stopcountstore = formallactivestopsarray($my_connection,$id);
	$result_string = file_get_contents($url);
	//echo $result_string;
	$result = json_decode($result_string, true);
	$foricount =0;
	for($i; $i<count($result['rows'][0]['elements']);$i++){
		$time = $result['rows'][0]['elements'][$i]['duration']['value'];
		if($time<450)		
		//if($acc<200)
		{
			$temp = explode(",",$stopcountstore); 
			echo  $stop = $temp[$foricount];
			$query="SELECT * FROM `bus_stops` WHERE `bus_id` = $busid and `stop_number` ='$stop'";
			$result = mysql_query( $query , $my_connection) or die(mysql_error());
			$stopnme ="no stop";
			while($row = mysql_fetch_array($result)) {
				$stopnme = $row['name'];				
			}
			
			sendmessage($my_connection,$busid ,$stop,$stopnme);
			
		}
		$foricount++;
		
		
	}
	for($i; $i<count($result['rows'][0]['elements']);$i++){
		$dist= $result['rows'][0]['elements'][$i]['distance']['value'];
		if($dist<200){
			if($acc<100){
			sendreached($my_connection,$i);
			}
			else{
				
			}
		}
		
	}
	$stopcountstore ="";
			
	function formallactivestops($my_connection,$id){
		$query="SELECT * FROM `dailytrips` WHERE `bus_id` = $id and `active` ='yes'";
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		$returnstring ="";
		while($row = mysql_fetch_array($result)) {
			$stopcountstore .= $row['stopnumber'].",";
			$returnstring .= $row['lat']. "+" .$row['long']."|";
		}
		$stopcountstore  = rtrim($stopcountstore , ",");
		//echo "stops ry: ".$stopcountstore;
		$returnstring = rtrim($returnstring , "|");
		return $returnstring;
		
	}	
	function formallactivestopsarray($my_connection,$id){
		$query="SELECT * FROM `dailytrips` WHERE `bus_id` = $id and `active` ='yes'";
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		$returnstring ="";
		while($row = mysql_fetch_array($result)) {
			$stopcountstore .= $row['stopnumber'].",";
			
		}
		$stopcountstore  = rtrim($stopcountstore , ",");
		
		return $stopcountstore;
		
	}	
	
	function sendmessage($my_connection,$busid, $stopid,$stopnme){
		//echo $stopid;
		echo $query="UPDATE `dailytrips` SET `messagesent`='yes' WHERE `active`='yes' AND `bus_id` = $busid AND `stop_id` = $stopid";
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		

                //sedning mil
                $from = "webmaster@scoolus.com"; // sender
    $subject = "bus reched: ";
    $message = "distance to next stop ". $stopnme .": ";
    // message lines should not exceed 70 characters (PHP rule), so wrap it
    $message = wordwrap($message, 70);
    // send mail
    mail("yyeshwanth4@gmail.com",$subject,$message,"From: $from\n");


	}	
	function sendreached($my_connection,$id){
		
	}
	
	function checktime($my_connection, $id){
		$query="SELECT * FROM `hits` WHERE bus_id = '$id' AND  DATE(date) = CURDATE()";
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		$count ="null";
		while($row = mysql_fetch_array($result)) {
			$sleep = strtotime($row['sleep']);
			$wake = strtotime($row['wake']);
			$subTime = $wake - $sleep;
			$y = ($subTime/(60*60*24*365));
			$d = ($subTime/(60*60*24))%365;
			$h = ($subTime/(60*60))%24;
			$m = ($subTime/60)%60;
			if($d == 0 && $h ==0){
				return $m;
			}
			else{
				return 0;
			}
		}
		
		// if record is not ter for today create
		$query = "INSERT INTO `hits`( `count`, `bus_id`, `date`, `sleep`, `wake`) VALUES (0, '$id',NOW(),NOW(),NOW())";
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		
		
	}
?>