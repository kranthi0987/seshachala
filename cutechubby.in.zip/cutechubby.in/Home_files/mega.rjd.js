/**
 * ------------------------------------------------------------------------
 * JA Puresite Template J25
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - Copyrighted Commercial Software
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites:  http://www.joomlart.com -  http://www.joomlancers.com
 * This file may not be redistributed in whole or significant part.
 * ------------------------------------------------------------------------
 */

/**
 * Extended js to make mega menu responsive
 * wide: normal menu (apply for desktop)
 * narrow: show 2 level menu only, use click event to show/hide submenu (apply for tabless)
 * tiny: only the first level menu, as submenu of a menu button (apply for mobile)
 */

 //add menu button to use in small and/or tiny screen
 document.addEvent ('domready', function () {
	var jmega = $('ja-megamenu');

	if (jmega && !(Browser.ie && Browser.version < 9)) {
		var jlevel0 = jmega.getElement('ul.level0');
		if(jlevel0){
			var jmnbutton = new Element ('div', {id:'ja-menu-button', html: 'Navigation'}).inject (jmega, 'before'),
				iidMain = null,
				show = 0;

			jmnbutton.addEvent('click', function(e){
				e.stop();
				if(show){
					jmega.removeClass('active').setStyle('display', 'none');
					jmnbutton.removeClass('active');
					show = 0;
				} else {
					jmega.addClass('active').setStyle('display', 'block');
					jmnbutton.addClass('active');
					show = 1;
				}
			});

			$(document).addEvent('click', function(){
				if($(window).getWidth() <= 735){
					jmega.removeClass('active').setStyle('display', 'none');
					show = 0;
				}

				jmnbutton.removeClass('active');
			});

			jmega.setStyle('display', 'none');

			var response = function(){
				jmega.setStyle('display', ($(window).getWidth() <= 735 && !show) ? 'none' : 'block');
			};

			$(window).addEvent('resize', response);

			response();
		}
	}
 });
