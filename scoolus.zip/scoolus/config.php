<?php
	$db_host="localhost";
	$db_user = "seshacha_all";
	$db_pass = "mrf123yes";
?>