<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
	$long =  $_GET["long"];
	$lat  =  $_GET["lat"];
	//echo $long . $lat;
		
		$query ="SELECT * FROM `trck` order by `rid` DESC LIMIT 1";
		
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
		while($row = mysql_fetch_array($result)) {
			echo $row['long'] ."," .$row['lat'];	
		}
?>