<?php
	$db_host="localhost";
	$db_user = "sheshsiu_trail1";
	$db_pass = "mrf123yes";
?>