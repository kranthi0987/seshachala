<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bus Manager</title>
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<link rel="stylesheet" href="css/bootstrap.css"/>
<link rel="stylesheet" href="css/bootstrapValidator.min.css"/>

<link rel="stylesheet" href="css/main.css">
<style>
  #sortable { list-style-type: none; margin: 8; padding: 0; }
  #sortable li { margin: 0 5px 5px 5px; padding: 5px; font-size: 1.2em; height: 1.5em; }
  html>body #sortable li { height: 1.5em; line-height: 1.2em; }
  .ui-state-highlight { height: 1.5em; line-height: 1.2em; }
  </style>
  
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript">
      $(document).ready(function(){
		  var url22 ="http://seshachalavanadarshani.com/scoolus/bus-list.php";
			
			/// call your function here
			$.ajax({url:url22,success:function(result){
				$( "table.table tbody" ).html("");	
				//alert(result);
		  		var list = result.split(",,,");	 
			    for(var i = 0 ; i< list.length; i++){
					var list2 = list[i].split("///");	 
				    	//alert("<option id='"+ list2[0]+"'>"+list2[1]+"</option>" );
						$( "<tr><td>"+i+"</td><td>"+list2[1]+"</td><td>"+list2[2]+"</td></tr>" ).appendTo( "table.table tbody" );	
						
						
				}
				
			}});
		 $("#cretust").click(function(){
			 var url2 ="http://seshachalavanadarshani.com/scoolus/bus-list.php";
			
			/// call your function here
			$.ajax({url:url2,success:function(result){
									$( "table.table tbody" ).html("");	
				//alert(result);
		  		var list = result.split(",,,");	 
			    for(var i = 0 ; i< list.length; i++){
					var list2 = list[i].split("///");	 
				    	//alert("<option id='"+ list2[0]+"'>"+list2[1]+"</option>" );
						$( "<tr><td>"+i+"</td><td>"+list2[1]+"</td><td>"+list2[2]+"</td></tr>" ).appendTo( "table.table tbody" );	
						
						
				}
				
			}});
		 });
		 $("#ctretus").click(function(event){	
			event.preventDefault();
			if($('#busnum').val() == ""){
				
				alert("please fill bus number");
			}
			else{
				var url2 ="http://seshachalavanadarshani.com/scoolus/createbus.php?num="+$('#busnum').val();
				
			    /// call your function here
			    $.ajax({url:url2,success:function(result){
				    var url26 ="http://seshachalavanadarshani.com/scoolus/bus-list.php";
					/// call your function here
					$.ajax({url:url26,success:function(result){
						$( "table.table tbody" ).html("");	
					
						//alert(result);
						var list = result.split(",,,");	 
						for(var i = 0 ; i< list.length; i++){
							var list2 = list[i].split("///");	 
								//alert("<option id='"+ list2[0]+"'>"+list2[1]+"</option>" );
								$( "<tr><td>"+i+"</td><td>"+list2[1]+"</td><td>"+list2[2]+"</td></tr>" ).appendTo( "table.table tbody" );	
								
								
						}
						
					}});
				  
		  	    }});
			}
		 
		 });
		 
		 // dragable
		 $( "#sortable" ).sortable({
			  placeholder: "ui-state-highlight"
			});
         $( "#sortable" ).disableSelection();
		 
		 $("#addstop").click(function(event){
			event.preventDefault();
			//alert("hi");
			if( $("#long").val() == ""){
				alert("Fill values");	
				return;
			}
			if( $("#lat").val() == ""){
				alert("Fill values");	
				return;
			}
			if( $("#stopnme").val() == ""){
				alert("Fill values");	
			}else{
				
				$( "<div id='sortlisthold' dbid='---' long='"+$("#long").val()+"'  lat='"+$("#lat").val()+"' stop='"+$("#stopnme").val()+"'  class='input-group holder' class='btn btn-default'><span class='input-group-addon'><icon class='removelist glyphicon glyphicon-remove '></icon></span><div class='' style='padding:8px;'>"+$("#stopnme").val()+"</div><span class='input-group-addon'><icon class='glyphicon glyphicon-resize-vertical'></icon></span></div>" ).appendTo( "#sortable" );	 
				}
		 });
		 

		 // us nmes loding
		 $("#crtstop").one('click',function(){
			
			var url2 ="http://seshachalavanadarshani.com/scoolus/busnames.php";
			
			/// call your function here
			$.ajax({url:url2,success:function(result){
				//alert(result);
		  		var id ="";
				var list = result.split(",,,");	 
			    for(var i = 0 ; i< list.length; i++){
					var list2 = list[i].split("///");	 
				    	//alert("<option id='"+ list2[0]+"'>"+list2[1]+"</option>" );
						$( "<option id='"+ list2[0]+"'>"+list2[1]+"</option>" ).appendTo( "#buslist" );	
						if( i == 0){
							id = list2[0];
						}
						
				}
				if(list.length >0){
					var url3 = "http://seshachalavanadarshani.com/scoolus/stopnames.php?bus="+id;
					$.ajax({url:url3,success:function(result){
						var stops = result.split(",,,");
						
						for( var i =0; i< stops.length; i++){
							if(stops[i] !=""){
								var more = stops[i].split("///");
								$( "<div id='sortlisthold' dbid = '"+more[3]+"' long='"+more[2]+"' lat='"+more[1]+"' stop='"+more[0]+"'  class='input-group holder' class='btn btn-default'><span class='input-group-addon'><icon class='removelist glyphicon glyphicon-remove '></icon></span><div class='' style='padding:8px;'>"+more[0]+"</div><span class='input-group-addon'><icon class='glyphicon glyphicon-resize-vertical'></icon></span></div>" ).appendTo( "#sortable" );	
							}
						}
					}});
				}
				
						$(stopslod).hide();
						$(stopshold).show();
						
			}});	 
		 });
		 
		 // us select  chnge
		 $('#buslist').on('change', function() {
		  //alert( $(this).children(":selected").attr("id") ); // or $(this).val()
		  
		  var url3 = "http://seshachalavanadarshani.com/scoolus/stopnames.php?bus="+$(this).children(":selected").attr("id");
			$.ajax({url:url3,success:function(result){
				$("#sortable").html("");
				var stops = result.split(",,,");
				for( var i =0; i< stops.length; i++){
					if(stops[i] !=""){
						var more = stops[i].split("///");
								$( "<div id='sortlisthold' dbid = '"+more[3]+"' long='"+more[2]+"' lat='"+more[1]+"' stop='"+more[0]+"'  class='input-group holder' class='btn btn-default'><span class='input-group-addon'><icon class='removelist glyphicon glyphicon-remove '></icon></span><div class='' style='padding:8px;'>"+more[0]+"</div><span class='input-group-addon'><icon class='glyphicon glyphicon-resize-vertical'></icon></span></div>" ).appendTo( "#sortable" );	
	
	
					}
				}
			}});
		});
	  	
		
				
		
			$(document).on('click', '#updatestop',function(){
				var xxx = $('<div>' + $("#sortable").html() + '</div>');
				//alert(xxx);
				 var id = $("#buslist").children(":selected").attr("id")
				 var up = id +"!!!";		
				for(var i =0; i< xxx.find(".input-group").length; i++){
						var j = i+1;
						//alert(xxx.find(".input-group:nth-child("+j+")").html());
						var stop = xxx.find(".input-group:nth-child("+j+")").attr("stop");
						var lat = xxx.find(".input-group:nth-child("+j+")").attr("lat");
						var long = xxx.find(".input-group:nth-child("+j+")").attr("long");
						var dbid = xxx.find(".input-group:nth-child("+j+")").attr("dbid");
						up += stop +"///"+ lat + "///" +long + "///" +dbid+ ",,,";
						//xxx.find(".input-group:not(.done:first)").addClass("done");
				}
				up = up.slice(0,-3)
				//alert(up);
				console.log(up);
				var url3 = "http://seshachalavanadarshani.com/scoolus/updateroute.php?data="+up;
				$.ajax({url:url3,success:function(result){
					
					var url3 = "http://seshachalavanadarshani.com/scoolus/stopnames.php?bus="+$("#buslist").children(":selected").attr("id");
					$.ajax({url:url3,success:function(result){
						$("#sortable").html("");
						var stops = result.split(",,,");
						for( var i =0; i< stops.length; i++){
							if(stops[i] !=""){
								var more = stops[i].split("///");
										$( "<div id='sortlisthold' dbid = '"+more[3]+"' long='"+more[2]+"' lat='"+more[1]+"' stop='"+more[0]+"'  class='input-group holder' class='btn btn-default'><span class='input-group-addon'><icon class='removelist glyphicon glyphicon-remove '></icon></span><div class='' style='padding:8px;'>"+more[0]+"</div><span class='input-group-addon'><icon class='glyphicon glyphicon-resize-vertical'></icon></span></div>" ).appendTo( "#sortable" );	
			
			
							}
						}
					}});
					alert("Updated");
				}});
				
			});
		
			
			// remove from list
			$('#sortable').on('click', 'div .removelist', function(){
			
				//alert("hi
				if($(this).closest(".holder").attr("dbid") == "---"){
					$(this).closest(".holder").remove();
				}
				else{
					alert("Already existing Bus stops cant be removed from here");
				}
				
//				this.closest("#sortlisthold").remove();
			});
			
		});
	  	
	  
    </script>
</head>

<body>
	<div id="wrapper">
        <div id="menu">
            <span class="logocontaner">
				<img src="img/logo.png" />
			</span>
            <ul id="links">
            	<a href="index.php">Track Bus</a>
                <a class="active" href="home.php">Bus Manager</a>
            	<a href="studentmanager.php">Student Manager</a>
            	<a href ="messagemanager.php" >Message Manager</a>
            </ul>
        </div>
        <div id="content" class="">
            <div class="col-sm-3" style="padding-right: 0px;">
                <div class="sidebar-nav">
                    <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
                        <li class="active"><a id="cretust" href="#buscreate" data-toggle="tab">Create Bus</a></li>
                        <li id="crtstop"><a href="#orange" data-toggle="tab">Create Stops</a></li>
                        
                    </ul>
                </div>
            </div>
           
            
            <div class="col-sm-9 maincontent" style="min-height:100px;">
			
			
                <div class="sidebar-nav">
             		<!-------->
                    <div id="tabcontent">
                        
                        <div id="my-tab-content" class="tab-content">
                            <div class="tab-pane active" id="buscreate">
                                <div class="page-header">
						  <h1><small>Create Bus routes</small></>
						</div><form class="form-horizontal" role="form">
                                    <div class="form-group">
                                      <label for="busnum" class="col-sm-2 control-label">Bus Number</label>
                                      <div class="col-sm-10">
                                         <input type="text" class="form-control" id="busnum" 
                                            placeholder="Enter Bus Number">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <div class="col-sm-offset-10 col-sm-2">
                                         <button id="ctretus" type="submit" class="btn btn-default col-sm-12">Create</button>
                                      </div>
                                   </div>
								</form>
                                <div class="page-header">
						  <h1><small>List of Bus routes</small></>
						</div>
                                    
                                <table class="table" width="647">
                                <thead>
                                <tr>
                                <th>#</th>
                                <th>Number</th>
                                <th>Stops</th>
                                </tr>
                                </thead>
                                <tbody>
                                
                                </tbody>
                                </table>                                    
                            </div>
                            <div class="tab-pane" id="orange">
                                <div id="stopslod" style="padding:55px;">
									<center><img width="30" src="img/ajax-loader.gif" /></center>
                                </div>
                                <div id="stopshold" class="fade in">
                                    <div class="page-header">
						  <h1>Define Stops</>
						</div>
                                    <div class="row">
    
                                        <div class="form-group">
                                            <label for="busnum" class="col-sm-2 control-label">select bus</label>
                                              <div class="col-sm-5">
                                                <select id="buslist" class="form-control" >
                                                	
                                                </select>
                                              </div>
                                            	
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-sm-7">
                                           	<div class="page-header">
						  <h1><small>Add Bus Stops</small></>
						</div>
	
                                            <form class="form-horizontal" role="form">
                                                <div class="form-group">
                                                  <label for="busnum" class="col-sm-4 control-label">Add Stop Name</label>
                                                  <div class="col-sm-8">
                                                     <input type="text" class="form-control" id="stopnme" 
                                                        placeholder="Enter Stop Name">
                                                  </div>
                                                </div>
                                                <div class="form-group row">
                                                  <div class="col-sm-offset-4 col-sm-4">
                                                     <input type="text" class="form-control" id="long" 
                                                        placeholder="Enter Longitude">
                                                  </div>
                                                  <div class=" col-sm-4">
                                                     <input type="text" class="form-control" id="lat" 
                                                        placeholder="Enter Latitude">
                                                  </div>
                                               </div>
                                                <div class="form-group row">
                                                  <div class="col-sm-offset-8 col-sm-4">
                                                     <button id="addstop" type="submit" class="btn btn-default col-sm-12">Add <span class="glyphicon glyphicon-arrow-right"></span></button>
                                                  </div>
                                               </div>
                                            </form>
                                        </div>
                                        <div class="col-sm-5" class="sorthold">
                                            <div class="page-header">
						  <h1><small>Added Bus Stops</small></>
						</div>
                                            <ul id="sortable" class="col-sm-12">
                                              	
                                            </ul>
     										
                                            <div class="form-group">
                                              <div class=" col-sm-12">
                                                 <button id="updatestop" type="submit" class="btn btn-default col-sm-12">Update Route</button>
                                              </div>
                                           </div>
                                        </div>
                                    </div>
                                </div>    
                            </div>
                            
                        </div>
                    </div>
             	</div>
            </div>    
            
			<div style="clear: both;"></div>
	</div>
	
	
<div class="footer">
	<div class="inner2">
	 
	</div>
</div>	
</body>
</html>