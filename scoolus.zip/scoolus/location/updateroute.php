<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
	$data =  $_GET["data"];
	
	$data = split ("!!!", $data);
	$id = $data[0];
	
	// commented to stop deleting the rows
	//$query="DELETE  FROM `bus_stops` WHERE `bus_id` =$id";
			
	 	
	//mysql_query( $query , $my_connection) or die(mysql_error());
		
	
	//echo $id;
	$rest = $data[1];
	//echo $rest;
	$resty = split(",,,", $rest);
	for($i =0; $i < sizeof($resty); $i++){
		$finl = split("///", $resty[$i]);
		
		if($finl[3] == "---"){	
			$query="INSERT INTO `bus_stops`(`bus_id`, `name`, `lat`, `long`, `stop_number`) VALUES ('$id','$finl[0]','$finl[1]','$finl[2]','$i')";
				
		 	$result = mysql_query( $query , $my_connection) or die(mysql_error());
		}
		else{
			$query="UPDATE `bus_stops` SET `bus_id`='$id',`name`='$finl[0]',`lat`='$finl[1]',`long`='$finl[2]',`stop_number`='$i' WHERE `id`= '$finl[3]'";
				
		 	$result = mysql_query( $query , $my_connection) or die(mysql_error());
		}
	}
	//echo $long . $lat;
	//	$query="UPDATE `trck` SET `long`=$long,`lat`=$lat WHERE `id`=1";
			
	//	$result = mysql_query( $query , $my_connection) or die(mysql_error());
		
?>