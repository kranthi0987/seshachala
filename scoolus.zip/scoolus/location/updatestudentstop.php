<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
	$busid =  $_GET["busid"];
	$sid =  $_GET["sid"];
	$data =  $_GET["data"];
	
	$data1 = split (",,,", $data);
	for($i =0; $i < sizeof($data1); $i++){
			echo $query="UPDATE `Student` SET `bus_id`='$busid',`busstop_id`='$sid' WHERE `id`= '$data1[$i]'";
				
		 	$result = mysql_query( $query , $my_connection) or die(mysql_error());
		
	}
	
?>