<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
	$data =  $_GET["data"];
	$query="UPDATE `hits` SET `count`='$data' WHERE `id`='1'";
				
	$result = mysql_query( $query , $my_connection) or die(mysql_error());
	
?>