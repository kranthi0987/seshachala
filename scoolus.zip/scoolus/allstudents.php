<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
		
		$bus = $_GET["bus"];
		//echo $bus;
		$query ="SELECT * FROM `Student`   ORDER BY `class`";
		$out ="";
		$result = mysql_query( $query , $my_connection) or die(mysql_error());
?>

<table>
<thead>
	<tr>
		<th>#</th>
		<th>Class</th>
		<th>Roll</th>
		<th>Firstname</th>
		<th>Lastname</th>
		<th>Gaurdian</th>
		<th>Phone</th>
		<th>Bus</th>
		<th>Stop</th>
		<th>Action</th>
	</tr>
</thead>

<tfoot>
	<tr>
		<th>#</th>
		<th>Class</th>
		<th>Roll</th>
		<th>Firstname</th>
		<th>Lastname</th>
		<th>Gaurdian</th>
		<th>Phone</th>
		<th>Bus</th>
		<th>Stop</th>
		<th>Action</th>
	</tr>
</tfoot>
<tbody>
<?php		
$count = 1;
		while($row = mysql_fetch_array($result)) {
?>
	<tr>
		<td><?php echo $count; ?></td>
		<td><?php echo $row['class']; ?></td>
		<td><?php echo $row['rollnumber']; ?></td>
		<td><?php echo $row['firstname']; ?></td>
		<td><?php echo $row['lastname']; ?></td>
		<td><?php echo $row['gaurdian']; ?></td>
		<td><?php echo $row['phone']; ?></td>
		<td class="busrelated"><?php echo $row['bus_id']; ?></td>
		<td class="busrelated"><?php echo $row['busstop_id']; ?></td>
		<td><a id="<?php echo $row['id']?>" class="disalocatestudent" href="#">Dis-allocate</a></td>
	</tr>	
<?php		
$count++;	
		}
		$out = rtrim($out,",,,");
		echo $out;
?>

</tbody>
</table>
