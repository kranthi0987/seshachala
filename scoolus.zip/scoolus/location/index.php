<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Scoolus Bus application</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<script type="text/javascript" src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>

<link rel="stylesheet" href="css/main.css">
<style type="text/css">
	
</style>

<style type="text/css">
      html { height: 100% }
      body { height: 100%; margin: 0; padding: 0 }
      #map-canvas { min-height: 400px; }
	.nav li{
		width: auto;	
	}
		.nav-tabs>li.active>a, .nav-tabs>li.active>a:hover, .nav-tabs>li.active>a:focus {
	color: #555;
	background-color: #fff;
	border: 1px solid #ddd;
	border-bottom-color: transparent;
	cursor: default;
	}
</style>
    <script type="text/javascript"
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAvK5TmfFTA9cmljPD6lbw1W7YqiaAwfSo&sensor=SET_TO_TRUE_OR_FALSE">
    </script>
    <script type="text/javascript">
				var directionsDisplay;
		var directionsService = new google.maps.DirectionsService();		
		var id=0;
		var busimage = 'img/bus.png';	
        var map;
		var marker;
		var idchng =0;
      function initialize() {
		directionsDisplay = new google.maps.DirectionsRenderer();
		var long = 80.214354;
		var lat = 13.128085;
		
		var myLatlng = new google.maps.LatLng(lat,long);

		var mapOptions = {
          center: myLatlng,
          zoom: 14
        };
        map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
		directionsDisplay.setMap(map);
		
		marker = new google.maps.Marker({
			position: myLatlng,
			map: map,
			title:"bus location"
		});
		
		var zoom = 17;
		var countz =0;
		window.setInterval(function(){
			if(id ==0){
				return;
			}
			// if id changed draw route
			if(idchng !=0){
					
			}
			var url2 ="http://seshachalavanadarshani.com/scoolus/getcurrentlocation.php?id="+id;
			console.log(url2);
		  /// call your function here
		  $.ajax({url:url2,success:function(result){
			  //alert(result);
			  var resulty = result.split(","); 
			  console.log(resulty.length);
			  if(resulty.length ==1){
				return;  
			  }
			  if(lat == resulty[1] && long == resulty[0]){
				console.log("already pointing to same location");
			    
			  }
			  else{
				  marker.setMap(null);
				  long = resulty[0];
				  lat = resulty[1];	
				  console.log(long+","+lat);
				  myLatlng = new google.maps.LatLng(lat,long);	
				  marker = new google.maps.Marker({
						position: myLatlng,
						map: map,
						title:"bus location",
						icon: busimage
					});
				  map.panTo( myLatlng );
				  if(countz ==0){
					  countz++;
				  	map.setZoom(zoom);
				  }
			  }
			  
		  }});
		
		}, 1000*6);
		
	  }
      google.maps.event.addDomListener(window, 'load', initialize);
	  
	  
	  $(document).ready(function(){
		 var url22 ="http://seshachalavanadarshani.com/scoolus/bus-list.php";
		$.ajax({url:url22,success:function(result){
			
			var busarray = result.split(",,,");	
			for(var i = 0; i< busarray.length;i++){
				//alert(busarray[i]);
				var final = busarray[i].split("///");
				$("<li><a id='"+final[0]+"' class='busdrop' data-toggle='tab' href='#bus"+i+"'>"+final[1]+"</a></li>").appendTo(".dropdown-menu");
			}
		}});
		$(".dropdown-menu").on("click",".busdrop", function(){
				//alert($(this).attr("id"));
				id  = $(this).attr("id");
				idchng++;
				setRoute();
				$("#heading").html("Tracking bus: "+$(this).html());
		});
			
		
	  });

	  
	function setRoute() {
	  
	  var start;
	  var end;	  
	  var waypts = [];
	  // push loc to wypoints
	  var url2 ="http://seshachalavanadarshani.com/scoolus/getlistofstopsa.php?id="+id;
	  console.log(url2);
	  /// call your function here
	  $.ajax({url:url2,success:function(result){
		  //alert(result);
		  var resulty = result.split(",,,");
		  for(var i =0; i< resulty.length;i++){
			var fin = resulty[i].split("///");
			if(i ==0){
				console.log(fin[1]+",,,"+fin[2]+"---"+i);
				start = new google.maps.LatLng(fin[1],fin[2]);
			}
			else if(i == resulty.length-1){
				console.log(fin[1]+",,,"+fin[2]+"---"+i);
				end = new google.maps.LatLng(fin[1],fin[2]);
			}
			else{
				console.log(fin[1]+",,,"+fin[2]+"---"+i);
				waypts.push({
				  location: new google.maps.LatLng(fin[1],fin[2]),
				  stopover:true
				});
			}
		  }
		  
		  
		  var request = {
			  origin: start,
			  destination: end,
			  waypoints: waypts,
			  optimizeWaypoints: true,
			  travelMode: google.maps.TravelMode.DRIVING
		  };
		  
		  directionsService.route(request, function(response, status) {
			if (status == google.maps.DirectionsStatus.OK) {
			  directionsDisplay.setDirections(response);
			  var route = response.routes[0];
			  // For each route, display summary information.
			  
			  
			}
		  });
	  }});
	  
	  
	}
    </script>
</head>
<body>

<div id="menu">
            <ul id="links">
            	<li class="active"><a href="index.php">Track Bus</a></li>
                <li class=""><a href="home.php">Bus Manager</a></li>
            	<li><a href="studentmanager.php">Student Manager</a></li>
            	<li><a href ="messagemanager.php" >Message Manager</a></li>
            </ul>
        </div>
<div class="bs-example">
    <ul class="nav nav-tabs">
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">Select Bus <b class="caret"></b></a>
            <ul class="dropdown-menu">
                
            </ul>
        </li>
    </ul>
    <div class="tab-content">
        <div id="sectionA" class="tab-pane fade in active">
            <h3 id="heading">Please select a bus to track</h3>
            <div id="map-canvas"/>
        </div>
        
    </div>
</div>
</div>
<div class="footer">
	<div class="inner2">
	 
	</div>
</div>
</body>
</html>                                		