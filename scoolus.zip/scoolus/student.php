<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Bus Manager</title>
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.min.css">
<link rel="stylesheet" href="css/main.css">
<style>
  #sortable { list-style-type: none; margin: 8; padding: 0; }
  #sortable li { margin: 0 5px 5px 5px; padding: 5px; font-size: 1.2em; height: 1.5em; }
  html>body #sortable li { height: 1.5em; line-height: 1.2em; }
  .ui-state-highlight { height: 1.5em; line-height: 1.2em; }
  </style>
  
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script src="js/bootstrap.min.js"></script>
<link rel="stylesheet" href="css/bootstrap.css"/>
<link rel="stylesheet" href="css/bootstrapValidator.min.css"/>

<script type="text/javascript">
  $(document).ready(function(){
		$("#regstudnt").click( function(event){
			event.preventDefault();
			
		});
  });
  
  
	  	
	  
    </script>
</head>

<body>
	<div id="wrapper">
        <div id="menu">
            
        </div>
        <div id="content">
            <div class="col-sm-3" style="padding-right: 0px;">
                <div class="sidebar-nav">
                    <ul id="tabs" class="nav nav-tabs" data-tabs="tabs">
                        <li class="active"><a href="#studcreate" data-toggle="tab">Register Student</a></li>
                        <li id="crtstop"><a href="#orange" data-toggle="tab">Add Students to stops</a></li>
                        
                    </ul>
                </div>
              </div>
            </div>
            
            <div class="col-sm-9 maincontent" style="min-height:100px;">
                <div class="sidebar-nav">
             		<!-------->
                    <div id="tabcontent">
                        
                        <div id="my-tab-content" class="tab-content">
                            <div class="tab-pane active" id="studcreate">
                                <h1>Register Students</h1>
                                <form id="register" class="form-horizontal col-sm-8" role="form">
                                    <div class="form-group">
                                      <label for="rollnum" class="col-sm-4 control-label">Roll Number</label>
                                      <div class="col-sm-8">
                                         <input type="text" class="form-control" id="rollnum" 
                                            placeholder="Enter Roll Number">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label for="class" class="col-sm-4 control-label">Class</label>
                                      <div class="col-sm-8">
                                         <input type="text" class="form-control" id="class" 
                                            placeholder="Class">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label for="firstname" class="col-sm-4 control-label">Firstname</label>
                                      <div class="col-sm-8">
                                         <input type="text" class="form-control" id="fisrtname" 
                                            placeholder="Enter First Name">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label for="lastname" class="col-sm-4 control-label">Lastname</label>
                                      <div class="col-sm-8">
                                         <input type="text" class="form-control" id="busnum" 
                                            placeholder="Enter Last Name">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label for="gaurdian" class="col-sm-4 control-label">Guardian Name</label>
                                      <div class="col-sm-8">
                                         <input type="text" class="form-control" id="gaurdian" 
                                            placeholder="Enter Gaurdian Name">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <label for="phonenum" class="col-sm-4 control-label">Phone Number</label>
                                      <div class="col-sm-8">
                                         <input type="text" class="form-control" id="phonenum" 
                                            placeholder="Enter Phone Number">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                      <div class="col-sm-offset-8 col-sm-4">
                                         <button id="regstudnt" type="submit" name="submit" class="btn btn-default col-sm-12">Create</button>
                                      </div>
                                   </div>
								</form>
                                
                            </div>
                            <div class="tab-pane" id="orange">
                                <div id="stopslod" style="padding:55px;">
									<center><img width="30" src="img/ajax-loader.gif" /></center>
                                </div>
                                <div id="stopshold" class="fade in">
                                    <h1>Define Stops</h1>
                                    <div class="row">
    
                                        <div class="form-group">
                                            <label for="busnum" class="col-sm-2 control-label">select bus</label>
                                              <div class="col-sm-4">
                                                <select id="buslist" class="form-control" >
                                                	
                                                </select>
                                              </div>
                                            
                                        </div>
                                    </div>
                                    <br>
                                    <div class="row">
                                        <div class="col-sm-7">
                                            <form class="form-horizontal" role="form">
                                                <div class="form-group">
                                                  <label for="busnum" class="col-sm-4 control-label">Stop Name</label>
                                                  <div class="col-sm-8">
                                                     <input type="text" class="form-control" id="stopnme" 
                                                        placeholder="Enter Stop Name">
                                                  </div>
                                                </div>
                                                <div class="form-group row">
                                                  <div class="col-sm-offset-4 col-sm-4">
                                                     <input type="text" class="form-control" id="long" 
                                                        placeholder="Enter Longitude">
                                                  </div>
                                                  <div class=" col-sm-4">
                                                     <input type="text" class="form-control" id="lat" 
                                                        placeholder="Enter Latitude">
                                                  </div>
                                               </div>
                                                <div class="form-group row">
                                                  <div class="col-sm-offset-10 col-sm-2">
                                                     <button id="addstop" type="submit" class="btn btn-default col-sm-12">update</button>
                                                  </div>
                                               </div>
                                            </form>
                                        </div>
                                        <div class="col-sm-5" class="sorthold">
                                            
                                            <ul id="sortable" class="col-sm-12">
                                              	
                                            </ul>
     										
                                            <div class="form-group">
                                              <div class=" col-sm-12">
                                                 <button id="updatestop" type="submit" class="btn btn-default col-sm-12">Add</button>
                                              </div>
                                           </div>
                                        </div>
                                    </div>
                                </div>    
                            </div>
                            
                        </div>
                    </div>
             	</div>
            </div>    
            
        </div>
	</div>
</body>
</html>