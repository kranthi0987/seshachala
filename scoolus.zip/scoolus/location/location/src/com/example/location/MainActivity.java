package com.example.location;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import android.app.Activity;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.location.LocationClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;



public class MainActivity extends Activity implements GooglePlayServicesClient.ConnectionCallbacks,GooglePlayServicesClient.OnConnectionFailedListener,LocationListener {
	
//	private String TAG = this.getClass().getSimpleName();
	
//	private LocationClient locationclient;
//	private LocationRequest locationrequest;
//
	// GPSTracker class
    GPSTracker gps;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		
	    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
	    StrictMode.setThreadPolicy(policy);
	    
//	    int resp =GooglePlayServicesUtil.isGooglePlayServicesAvailable(this);
//		if(resp == ConnectionResult.SUCCESS){
//			locationclient = new LocationClient(this, this, this);
//			locationclient.connect();
//		}
//		else{
//			Toast.makeText(this, "Google Play Service Error " + resp, Toast.LENGTH_LONG).show();
//			
//		}
	}
	public String id;
	public void setid(String id){
	this.id = id;
	
	}
	public Handler mHandler = new Handler();
    public int count = 0;
    public Thread t;
	// Start the  service
	public void startNewService(View view) {
		

		
		gps = new GPSTracker(MainActivity.this);
		 
        // check if GPS enabled    
        if(gps.canGetLocation()){
             
        	//t.start();
        
        	
        	
	            double latitude = gps.getLatitude();
	            double longitude = gps.getLongitude();
	             
	            // \n is for new line
	            Toast.makeText(getApplicationContext(), "Your Location is - \nLat: " + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();   
        }else{
            // can't get location
            // GPS or Network is not enabled
            // Ask user to enable GPS/network in settings
            gps.showSettingsAlert();
        }
		
   
		//startService(new Intent(this, MyService.class));
	}

	// Stop the  service
	@SuppressWarnings("deprecation")
	public void stopNewService(View view) {
		t.stop();
		
		//stopService(new Intent(this, MyService.class));
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	public int k=0;
	@Override
	public void onBackPressed() {
	    // your code.
		if(k == 0){
			Toast.makeText(getApplicationContext(), "Press one more time to exit", Toast.LENGTH_LONG).show();
			k++;	
		}
		else{

			
			finish();
            System.exit(0);
		}
	}
	
	
	public void creatall(){
	    

 		// Creating HTTP Post
 		HttpPost httpPost = new HttpPost(
 				"http://www.seshachalavanadarshani.com/scoolus/getlisofbusa.php");

 		// Creating HTTP client
 		HttpClient httpClient = new DefaultHttpClient();
 		
 		InputStream is = null;

		String result = "";
		   
		    
 		// Making HTTP Request
 		try {
		

			HttpResponse response = httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
		    is = entity.getContent();
		      
			// writing response to log
			Log.d("Http Response:", response.toString());
			
			
			// start building button
			ScrollView sv = new ScrollView(this);
			LinearLayout ll = new LinearLayout(this);
			ll.setOrientation(LinearLayout.VERTICAL);
			sv.addView(ll);
			
			
		// convert response to string
		    try {
		      BufferedReader reader = new BufferedReader(new InputStreamReader(
		          is, "iso-8859-1"), 8);
		      StringBuilder sb = new StringBuilder();
		      String line = null;
		      while ((line = reader.readLine()) != null) {
		        sb.append(line );
		      }
		      is.close();
		      result = sb.toString();
		    } catch (Exception e) {
		      Log.e("log_tag", "Error converting result " + e.toString());
		    }
		    
			
			String[] splitString = result.split(",,,");
			for(int i = 0; i < splitString.length; i++) {
				Button b = new Button(this);
				String[] finalstr = splitString[i].split("///");
				b.setText(finalstr[1]);
				final String index = finalstr[0];
				b.setOnClickListener(new OnClickListener() {  
		            @Override  
		            public void onClick(View v) {  
		                // TODO Auto-generated method stub  
		            	//Toast.makeText(getApplicationContext(), "Started Route ", Toast.LENGTH_LONG).show();
		            	
		            	// ######get bus data from server#########

		        		// Creating HTTP Post
		        		HttpPost httpPost = new HttpPost(
		        				"http://seshachalavanadarshani.com/scoolus/getlistofstopsa.php?id="+index);

		        		// Creating HTTP client
		        		HttpClient httpClient = new DefaultHttpClient();
		        		
		        		InputStream is = null;

		       		    String result = "";
		       		   
		       		    
		        		// Making HTTP Request
		        		try {
		        			HttpResponse response = httpClient.execute(httpPost);
		        			HttpEntity entity = response.getEntity();
		        		    is = entity.getContent();
		        		      
		        			// writing response to log
		        			Log.d("Http Response:", response.toString());
		        			 		        			 		        			
		        			
		        		// convert response to string
		        		    try {
		        		      BufferedReader reader = new BufferedReader(new InputStreamReader(
		        		          is, "iso-8859-1"), 8);
		        		      StringBuilder sb = new StringBuilder();
		        		      String line = null;
		        		      while ((line = reader.readLine()) != null) {
		        		        sb.append(line );
		        		      }
		        		      is.close();
		        		      result = sb.toString();
		        		    } catch (Exception e) {
		        		      Log.e("log_tag", "Error converting result " + e.toString());
		        		    }
		        		    
		        		    
		        		    
		        		    
		        		}catch (ClientProtocolException e) {
		        			// writing exception to log
		        			e.printStackTrace();
		        		} catch (IOException e) {
		        			// writing exception to log
		        			e.printStackTrace();

		        		}
		            	
		        		if(result == ""){
		        			//Toast.makeText(getApplicationContext(), "No Stops").show();
		        			Log.e("log_tag", "no result : " + result);
		        			return;
		        		}
		        		else{
		        			
		        		
 		        		// start building view
		        			ScrollView nsv = new ScrollView(getApplicationContext());
		        			LinearLayout ll = new LinearLayout(getApplicationContext());
		        			ll.setOrientation(LinearLayout.VERTICAL);
		        			nsv.addView(ll);
		        			
 		        		// #######got result from server ###
 		        		
 		        		// design and show on server
 		        		String[] splitString = result.split(",,,");
 		    			
 		        		for(int i = 0; i < splitString.length; i++) {
 		        			String[] str = splitString[i].split("///");
 		        			TextView tv = new TextView(getApplicationContext());
 		        			tv.setTextSize(30);
 		        			tv.setText(str[3]);
 		        			ll.addView(tv);
 		        		}
 		        		
 		        		
 		        		// stop thred utton
 		        		Button b = new Button(getApplicationContext());
 		 				b.setText("Stop");
 		 				b.setOnClickListener(new OnClickListener() {  
 		 					 @Override  
 		 					 public void onClick(View v) {  
// 		 						AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getApplicationContext());
// 		 				 
// 		 							// set title
// 		 							alertDialogBuilder.setTitle("Conform ex");
// 		 				 
// 		 							// set dialog message
// 		 							alertDialogBuilder
// 		 								.setMessage("Click yes to exit!")
// 		 								.setCancelable(false)
// 		 								.setPositiveButton("Yes",new DialogInterface.OnClickListener() {
// 		 									public void onClick(DialogInterface dialog,int id) {
// 		 										// if this button is clicked, close
// 		 										// current activity
// 		 										finish();
// 		 							            System.exit(0);
// 		 									}
// 		 								  })
// 		 								.setNegativeButton("No",new DialogInterface.OnClickListener() {
// 		 									public void onClick(DialogInterface dialog,int id) {
// 		 										// if this button is clicked, just close
// 		 										// the dialog box and do nothing
// 		 										dialog.cancel();
// 		 									}
// 		 								});
// 		 				 
// 		 								// create alert dialog
// 		 								AlertDialog alertDialog = alertDialogBuilder.create();
// 		 				 
// 		 								// show it
// 		 								alertDialog.show();
 		 					 
 		 						finish();
					            System.exit(0);
 		 					 }
 		 				});
 		 				ll.addView(b);
 		 				setContentView(nsv);
 		        		setid(index);

        		    	gps = new GPSTracker(MainActivity.this);
	        	   		 
        	        	
	    	            double latitude1 = gps.getLatitude();
	    	            double longitude1 = gps.getLongitude();
	    	             
	    	            // \n is for new line
	    	            Toast.makeText(getApplicationContext(), "Start Location is - \nLat: " + latitude1 + "\nLong: " + longitude1, Toast.LENGTH_LONG).show();   
	    
 		        		
 		        		// ###### start thread here ####
 		        		Thread thread = new Thread(new Runnable(){
	        		    public void run(){
	        		    	//Toast.makeText(getApplicationContext(), "tthread running", Toast.LENGTH_LONG).show();
	        		    	    // check if GPS enabled    
		        	            if(gps.canGetLocation()){
		        	                 
		        	            	//t.start();
		        	            
		        	            	
		        	            
		        		            	
		        	    	            while (true) {
		        	    	                 try {
		        	    	                     Thread.sleep(1000*6);
		        	    	                     mHandler.post(new Runnable() {
		        	    	                    	 
		        	    	                         @Override
		        	    	                         public void run() {
		        	    	                             // TODO Auto-generated method stub
		        	    	                             // Write your code here to update the UI.
		        	    	                         	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		        	    	                     	    StrictMode.setThreadPolicy(policy);

		        	    	                     		// Creating HTTP client
		        	    	                     		HttpClient httpClient = new DefaultHttpClient();
		        	    	                     		
		        	    	                     		// getting logitude and latitude
		        	    	                     		
		        	    	                     		GPSTracker gps1 = new GPSTracker(getApplicationContext());
		        	    	                     		double latitude = gps1.getLatitude();
		        	    	             	            double longitude = gps1.getLongitude();
		        	    	             	           
		        	    	                     		
		        	    	                     		// Creating HTTP Post
		        	    	                     		HttpPost httpPost = new HttpPost(
		        	    	                     				"http://www.seshachalavanadarshani.com/scoolus/putcurrentposiotiona.php?id="+ id +"&long="+longitude+"&lat="+latitude);

		        	    	                     		

		        	    	                     		// Making HTTP Request
		        	    	                     		try {
		        	    	                     			HttpResponse response = httpClient.execute(httpPost);

		        	    	                     			// writing response to log
		        	    	                     			Log.d("Http Response:", response.toString());
		        	    	                     		} catch (ClientProtocolException e) {
		        	    	                     			// writing exception to log
		        	    	                     			e.printStackTrace();
		        	    	                     		} catch (IOException e) {
		        	    	                     			// writing exception to log
		        	    	                     			e.printStackTrace();

		        	    	                     		}
		        	    	                         	 
		        	    	                         }
		        	    	                     });
		        	    	                 } catch (Exception e) {
		        	    	                     // TODO: handle exception
		        	    	                 }
		        	    	             }
		        	            
		        	            }else{
		        	                // can't get location
		        	                // GPS or Network is not enabled
		        	                // Ask user to enable GPS/network in settings
		        	                gps.showSettingsAlert();
		        	            }
	        		    
        		    }
	        		    
        		    });

		        		thread.start();
		        		
		        		}	
		            }
		            	
				  
		        });
				ll.addView(b);
			}
			this.setContentView(sv);
			
 			
 		} catch (ClientProtocolException e) {
 			// writing exception to log
 			e.printStackTrace();
 		} catch (IOException e) {
 			// writing exception to log
 			e.printStackTrace();

 		}
			
		
	}

	@Override
	public void onConnected(Bundle connectionHint) {
//		Log.i(TAG, "onConnected");
		
	}

	@Override
	public void onDisconnected() {
//		Log.i(TAG, "onDisconnected");
		
	}

	@Override
	public void onConnectionFailed(ConnectionResult result) {
//		Log.i(TAG, "onConnectionFailed");
		
	}

	@Override
	public void onLocationChanged(Location location) {
		if(location!=null){
//			Log.i(TAG, "Location Request :" + location.getLatitude() + "," + location.getLongitude());
			
			
			HttpClient httpClient = new DefaultHttpClient();
	 		
     		// Creating HTTP Post
     		HttpPost httpPost = new HttpPost(
     				"http://www.seshachalavanadarshani.com/scoolus/putcurrentposiotiona.php?id="+ "1" +"&long="+ location.getLongitude() +"&lat="+ location.getLatitude() );

     		
     		Toast.makeText(this, "http://www.seshachalavanadarshani.com/scoolus/putcurrentposiotiona.php?id="+ "1" +"&long="+ location.getLongitude() +"&lat="+ location.getLatitude() , Toast.LENGTH_LONG).show();

    	    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
    	    StrictMode.setThreadPolicy(policy);
    	    
//     		// Making HTTP Request
//     		try {
//     			HttpResponse response = httpClient.execute(httpPost);
//
//     			// writing response to log
//     			Log.d("Http Response:", response.toString());
//     		} catch (ClientProtocolException e) {
//     			// writing exception to log
//     			e.printStackTrace();
//     		} catch (IOException e) {
//     			// writing exception to log
//     			e.printStackTrace();
//
//			}
		
	}
	
}
}