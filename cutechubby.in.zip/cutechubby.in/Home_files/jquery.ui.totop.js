/*
|--------------------------------------------------------------------------
| UItoTop jQuery Plugin 1.1
| http://www.mattvarone.com/web-design/uitotop-jquery-plugin/
|--------------------------------------------------------------------------
*/
var tz = jQuery.noConflict();
(function(tz){
	tz.fn.UItoTop = function(options) {

 		var defaults = {
			text: 'To Top',
			min: 200,
			inDelay:600,
			outDelay:400,
      containerID: 'toTop',
			containerHoverID: 'toTopHover',
			scrollSpeed: 1200,
			easingType: 'linear'
 		};

 		var settings = tz.extend(defaults, options);
		var containerIDhash = '#' + settings.containerID;
		var containerHoverIDHash = '#'+settings.containerHoverID;
		tz('body').append('<a href="#" id="'+settings.containerID+'">'+settings.text+'</a>');
		tz(containerIDhash).hide().click(function(){
			tz('html, body').animate({scrollTop:0}, settings.scrollSpeed, settings.easingType);
			tz('#'+settings.containerHoverID, this).stop().animate({'opacity': 0 }, settings.inDelay, settings.easingType);
			jQuery("#tz-mainnav a").css("text-decoration", "none");
			return false;
		})
		.prepend('<span id="'+settings.containerHoverID+'"></span>')
		.hover(function() {
				tz(containerHoverIDHash, this).stop().animate({
					'opacity': 1
				}, 600, 'linear');
			}, function() { 
				tz(containerHoverIDHash, this).stop().animate({
					'opacity': 0
				}, 700, 'linear');
			});
					
		tz(window).scroll(function() {
			var sd = tz(window).scrollTop();
			if(typeof document.body.style.maxHeight === "undefined") {
				tz(containerIDhash).css({
					'position': 'absolute',
					'top': tz(window).scrollTop() + tz(window).height() - 50
				});
			}
			if ( sd > settings.min ) 
				tz(containerIDhash).fadeIn(settings.inDelay);
			else 
				tz(containerIDhash).fadeOut(settings.Outdelay);
		});

};
})(jQuery);