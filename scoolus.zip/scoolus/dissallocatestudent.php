<?php
	include("config.php");
	$my_connection = mysql_connect($db_host , $db_user , $db_pass) or die("connection cont be made");
	mysql_select_db("seshacha_scoolus",$my_connection) or die("cant select db");
	$id =  $_GET["id"];
	$query="UPDATE `Student` SET`bus_id`='0',`busstop_id`='0'  WHERE `id`= $id";
		
	$result = mysql_query( $query , $my_connection) or die(mysql_error());
		
?>